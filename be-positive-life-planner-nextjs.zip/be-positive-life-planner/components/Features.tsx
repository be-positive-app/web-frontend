import { Bell, CalendarDays, CheckSquare, Crosshair, LineChart } from "lucide-react";

const features = [
  { icon: CheckSquare, title: "Smart task management" },
  { icon: CalendarDays, title: "Calendar planning" },
  { icon: Bell, title: "Daily reminders" },
  { icon: LineChart, title: "Progress tracking" },
  { icon: Crosshair, title: "Focus system" },
];

export default function Features() {
  return (
    <section className="features-section" id="features">
      <div className="container features-grid">
        <div>
          <div className="eyebrow">SIMPLE. BEAUTIFUL. EFFECTIVE.</div>
          <h2>Everything you need in one app.</h2>
          <div className="feature-list">
            {features.map(({ icon: Icon, title }) => (
              <div className="feature-item" key={title}>
                <span><Icon size={18} /></span>
                <p>{title}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="dashboard-preview">
          <div className="app-window">
            <div className="window-bar"><span /><span /><span /></div>
            <div className="window-body">
              <aside><b>Be Positive</b><small>Today</small><small>Tasks</small><small>Calendar</small><small>Statistics</small></aside>
              <div className="dashboard-main">
                <div className="dash-title"><div><small>Sunday, September 6</small><h3>Good morning! ☀️</h3></div><strong>75%</strong></div>
                <div className="dash-card">
                  <div><b>Today&apos;s tasks</b><small>6 of 8 completed</small></div>
                  <div className="fake-task done">✓ Morning workout <span>08:00</span></div>
                  <div className="fake-task done">✓ Team meeting <span>10:00</span></div>
                  <div className="fake-task">○ Design project <span>13:00</span></div>
                  <div className="fake-task">○ Read a book <span>20:00</span></div>
                </div>
                <div className="bar-chart"><i/><i/><i/><i/><i/><i/><i/></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}