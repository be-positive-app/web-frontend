const steps = [
  { number: "01", title: "Plan", text: "Add your tasks and organize your day.", tone: "yellow", icon: "✓" },
  { number: "02", title: "Remind", text: "Get notifications when you need them.", tone: "blue", icon: "◷" },
  { number: "03", title: "See results", text: "Track your performance and progress.", tone: "yellow", icon: "↗" },
];

export default function HowItWorks() {
  return (
    <section className="section" id="how-it-works">
      <div className="container">
        <div className="section-heading centered">
          <div className="eyebrow">HOW IT WORKS</div>
          <h2>Three simple steps<br />to a better day.</h2>
        </div>

        <div className="steps-grid">
          {steps.map((step) => (
            <article className={`step-card ${step.tone}`} key={step.number}>
              <span className="step-number">{step.number}</span>
              <div className="step-icon">{step.icon}</div>
              <h3>{step.title}</h3>
              <p>{step.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}