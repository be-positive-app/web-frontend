export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-inner">
        <div className="brand">
          <span className="brand-mark">✌</span>
          <span><strong>Be Positive</strong><small>Life Planner</small></span>
        </div>
        <p>Plan. Remind. Achieve.</p>
        <div className="footer-links">
          <a href="#">Privacy</a>
          <a href="#">Terms</a>
          <a href="mailto:hello@bepositive.az">Contact</a>
        </div>
      </div>
      <div className="container copyright">© 2026 Be Positive Life Planner. All rights reserved.</div>
    </footer>
  );
}