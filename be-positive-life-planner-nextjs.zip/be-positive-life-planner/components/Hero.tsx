import { CheckCircle2, Star } from "lucide-react";

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero-orb orb-one" />
      <div className="hero-orb orb-two" />

      <div className="container hero-grid">
        <div className="hero-content">
          <div className="eyebrow">YOUR PERSONAL DAILY PLANNER</div>

          <h1>
            Plan your day.
            <br />
            Stay focused.
            <br />
            <span>Feel positive.</span>
          </h1>

          <p className="hero-copy">
            Be Positive helps you manage your tasks, get timely reminders and
            track your daily progress — all in one simple app.
          </p>

          <div className="hero-actions">
            <a className="button primary" href="#download">Download App →</a>
            <a className="button secondary" href="#features">Explore features</a>
          </div>

          <div className="trust-row">
            <div className="avatar-stack">
              <span>AM</span><span>SA</span><span>LN</span><span>+1k</span>
            </div>
            <div>
              <div className="stars">
                <Star size={15} fill="currentColor" /> <Star size={15} fill="currentColor" />
                <Star size={15} fill="currentColor" /> <Star size={15} fill="currentColor" />
                <Star size={15} fill="currentColor" />
              </div>
              <small>Build a better daily routine.</small>
            </div>
          </div>
        </div>

        <div className="hero-visual">
          <div className="hero-yellow" />
          <div className="scribble">A better<br />you,<br /><u>every day.</u></div>

          <div className="phone phone-back">
            <div className="notch" />
            <div className="phone-screen">
              <div className="screen-top"><span>9:41</span><span>◉</span></div>
              <h3>Your Progress</h3>
              <div className="chart">
                <i /><i /><i /><i /><i /><i /><i />
              </div>
              <div className="mini-stats"><b>8<br/><small>Tasks</small></b><b>6<br/><small>Done</small></b></div>
            </div>
          </div>

          <div className="phone phone-front">
            <div className="notch" />
            <div className="phone-screen">
              <div className="screen-top"><span>9:41</span><span>◉</span></div>
              <p className="screen-kicker">Good morning! ☀️</p>
              <h3>Today's Progress</h3>
              <div className="progress-ring"><strong>75%</strong><small>complete</small></div>
              <div className="task-list">
                <div><CheckCircle2 size={17} /> Morning workout <span>08:00</span></div>
                <div><CheckCircle2 size={17} /> Team meeting <span>10:00</span></div>
                <div className="unfinished">○ Design work <span>13:00</span></div>
                <div className="unfinished">○ Read a book <span>20:00</span></div>
              </div>
              <div className="bottom-nav"><span>⌂</span><span>☷</span><b>+</b><span>▥</span><span>•••</span></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}