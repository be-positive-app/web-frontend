export default function DownloadCTA() {
  return (
    <section className="download" id="download">
      <div className="download-shape" />
      <div className="container download-inner">
        <div className="eyebrow">START TODAY</div>
        <h2>Your day. Your goals.<br /><span>Your progress.</span></h2>
        <p>Plan your day, stay focused and feel positive.</p>

        <div className="store-buttons">
          <a href="#" className="store-button"><b></b><span><small>Download on the</small>App Store</span></a>
          <a href="#" className="store-button"><b>▶</b><span><small>GET IT ON</small>Google Play</span></a>
        </div>
      </div>
    </section>
  );
}