 "use client";

import { useState } from "react";
import { Menu, X } from "lucide-react";

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="navbar">
      <div className="container nav-inner">
        <a href="#" className="brand">
          <span className="brand-mark">✌</span>
          <span>
            <strong>Be Positive</strong>
            <small>Life Planner</small>
          </span>
        </a>

        <nav className={open ? "nav-links open" : "nav-links"}>
          <a href="#features" onClick={() => setOpen(false)}>Features</a>
          <a href="#how-it-works" onClick={() => setOpen(false)}>How it works</a>
          <a href="#premium" onClick={() => setOpen(false)}>Premium</a>
          <a href="#faq" onClick={() => setOpen(false)}>FAQ</a>
        </nav>

        <a className="nav-cta" href="#download">Download App</a>

        <button
          className="mobile-menu"
          aria-label="Toggle menu"
          onClick={() => setOpen(!open)}
        >
          {open ? <X size={25} /> : <Menu size={25} />}
        </button>
      </div>
    </header>
  );
}