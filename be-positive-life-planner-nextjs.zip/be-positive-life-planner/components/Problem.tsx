import { Bell, Brain, Clock3 } from "lucide-react";

const problems = [
  { icon: Brain, title: "Lose focus easily?", text: "Too many things compete for your attention." },
  { icon: Clock3, title: "Forget important tasks?", text: "Keep everything you need to remember in one place." },
  { icon: Bell, title: "Need a little push?", text: "Get timely reminders without the noise." },
];

export default function Problem() {
  return (
    <section className="section problem">
      <div className="container problem-grid">
        <div>
          <div className="eyebrow">STRUGGLING TO STAY ORGANIZED?</div>
          <h2>Can&apos;t plan your work and often forget tasks?</h2>
          <p>Be Positive works like your personal assistant — planning, reminding and motivating you.</p>
        </div>

        <div className="problem-cards">
          {problems.map(({ icon: Icon, title, text }) => (
            <div className="problem-card" key={title}>
              <Icon size={28} />
              <h3>{title}</h3>
              <p>{text}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}