 "use client";

import { useState } from "react";
import { Plus } from "lucide-react";

const questions = [
  ["Is Be Positive free?", "Yes. The free plan lets you create a limited number of daily tasks and notifications. Premium unlocks more features."],
  ["Do I need an account?", "The first version is designed to be simple and can be used without registration."],
  ["Can I use reminders?", "Yes. You can choose how often Be Positive reminds you about your day."],
  ["Is there a Premium plan?", "Yes. Premium is designed for people who want unlimited tasks, more notifications and weekly analysis."],
];

export default function FAQ() {
  const [active, setActive] = useState<number | null>(null);

  return (
    <section className="section faq" id="faq">
      <div className="container faq-grid">
        <div>
          <div className="eyebrow">FAQ</div>
          <h2>Questions?<br />We&apos;ve got answers.</h2>
          <p>Everything you need to know before getting started.</p>
        </div>

        <div className="faq-list">
          {questions.map(([q, a], index) => (
            <button className="faq-item" key={q} onClick={() => setActive(active === index ? null : index)}>
              <div><strong>{q}</strong>{active === index && <p>{a}</p>}</div>
              <Plus className={active === index ? "rotated" : ""} size={22} />
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}