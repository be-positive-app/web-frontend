const screens = [
  { title: "My Tasks", subtitle: "Organize everything in one place", items: ["Morning workout", "Team meeting", "Design work", "Read a book"] },
  { title: "Calendar", subtitle: "See your day at a glance", items: ["Mon 7", "Tue 8", "Wed 9", "Thu 10"] },
  { title: "Statistics", subtitle: "Understand your progress", items: ["Today 75%", "Week 82%", "Month 88%", "12 day streak"] },
];

export default function AppShowcase() {
  return (
    <section className="section showcase">
      <div className="container">
        <div className="section-heading">
          <div className="eyebrow">MADE FOR REAL LIFE</div>
          <h2>Your whole day,<br />beautifully organized.</h2>
        </div>

        <div className="showcase-grid">
          {screens.map((screen, index) => (
            <div className="mock-phone" key={screen.title}>
              <div className="mock-notch" />
              <div className="mock-content">
                <small>{index === 0 ? "Today" : index === 1 ? "September" : "Your progress"}</small>
                <h3>{screen.title}</h3>
                <p>{screen.subtitle}</p>
                <div className={index === 2 ? "mock-chart" : "mock-list"}>
                  {screen.items.map((item, i) => (
                    <div key={item} className={i < 2 && index === 0 ? "mock-item checked" : "mock-item"}>
                      {index === 0 ? (i < 2 ? "✓" : "○") : index === 1 ? "•" : "▮"} <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}