const benefits = [
  "Unlimited tasks",
  "10 daily notifications",
  "Weekly analysis",
  "Premium themes",
  "Early access to new features",
];

export default function Premium() {
  return (
    <section className="premium-wrap" id="premium">
      <div className="container">
        <div className="premium-card">
          <div>
            <div className="eyebrow dark">GO PREMIUM</div>
            <h2>Unlock your<br />full potential.</h2>
            <p>More features. More focus. More progress.</p>
          </div>

          <div className="premium-list">
            {benefits.map((benefit) => <div key={benefit}>✓ <span>{benefit}</span></div>)}
          </div>

          <a className="button primary premium-button" href="#download">Go Premium →</a>
        </div>
      </div>
    </section>
  );
}