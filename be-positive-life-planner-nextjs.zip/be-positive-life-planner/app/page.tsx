import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import Problem from "@/components/Problem";
import HowItWorks from "@/components/HowItWorks";
import Features from "@/components/Features";
import AppShowcase from "@/components/AppShowcase";
import Premium from "@/components/Premium";
import FAQ from "@/components/FAQ";
import DownloadCTA from "@/components/DownloadCTA";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <>
      <Navbar />
      <main>
        <Hero />
        <Problem />
        <HowItWorks />
        <Features />
        <AppShowcase />
        <Premium />
        <FAQ />
        <DownloadCTA />
      </main>
      <Footer />
    </>
  );
}