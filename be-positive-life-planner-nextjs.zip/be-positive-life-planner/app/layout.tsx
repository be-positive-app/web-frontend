import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Be Positive Life Planner",
  description:
    "Plan your day, stay focused and track your progress with Be Positive Life Planner.",
  keywords: [
    "Be Positive",
    "Life Planner",
    "daily planner",
    "task manager",
    "productivity app",
    "habit tracker"
  ],
  openGraph: {
    title: "Be Positive Life Planner",
    description: "Plan your day. Stay focused. Feel positive.",
    type: "website"
  }
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}