# Be Positive Life Planner

Modern Next.js landing page for Be Positive Life Planner.

## Stack

- Next.js
- React
- TypeScript
- CSS
- Lucide React

## Run locally

```bash
npm install
npm run dev
```

Then open `http://localhost:3000`.

## Customize

- Replace the mock phone UI with real app screenshots in `components/Hero.tsx`, `Features.tsx`, and `AppShowcase.tsx`.
- Replace `#` App Store / Google Play links with your real store URLs.
- Replace the placeholder hand icon in the navbar/footer with the official Be Positive logo.
- Update metadata in `app/layout.tsx`.

## Deploy

Push the project to GitHub and import the repository into Vercel.
